 To run the project : 

1-Download project 
2-open Vue Directory 
3-npm install babel-core 
4-npm install css-loader 
5-npm install vue-loader 
6-npm install 

